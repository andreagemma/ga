from . import tictoc

__version__ = "2025.10.19"

__all__ = [
    "tictoc"
]